# Getting Back Into Code

This is a warm up exercise to kick off the semester. I'ts about remembering how to code! I'm gonna try to make a tick Tack Toe game.
