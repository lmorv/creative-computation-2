# This is an example of video capture in p5js

How to use the camera: Basic camera use, making a filter, using camera data. 
